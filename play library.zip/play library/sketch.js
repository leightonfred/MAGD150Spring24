let bricks, tilesGroup;

function setup() {
	new Canvas(500, 200);

	bricks = new Group();
	bricks.w = 20;
	bricks.h = 10;
	bricks.tile = '=';

	tilesGroup = new Tiles(
		[
			'=====...======',
			'======..======',
			'==..==..==....',
			'==..==..==....',
			'======..=====.',
			'=====...======',
			'==..........==',
			'==..........==',
			'==......======',
			'==......=====.'
		],
		100,
		40,
		bricks.w + 4,
		bricks.h + 4
	);
}

function draw() {
	//clear();

	for (let brick of bricks) {
		if (brick.mouse.hovers()) {
			brick.color = '#AA4A44';
		}
	}
}